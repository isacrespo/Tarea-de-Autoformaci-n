<?php
if(!defined('_PS_VERSION_'))
exit;

class isa_modTarea1 extends Module{

    public function __construct() {
        $this->name = 'isa_modTarea1'; //nombre del módulo el mismo que la carpeta y la clase.
        $this->tab = 'front_office_features'; // pestaña en la que se encuentra en el backoffice.
        $this->version = '1.0.0'; //versión del módulo
        $this->author ='Isa Crespo'; // autor del módulo
        $this->need_instance = 0; //si no necesita cargar la clase en la página módulos,1 si fuese necesario.
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); //las versiones con las que el módulo es compatible.
        $this->bootstrap = true; //si usa bootstrap plantilla responsive.

        parent::__construct(); //llamada al contructor padre.

        $this->displayName = $this->l('isa_modTarea1'); // Nombre del módulo
        $this->description = $this->l('Añade un mensaje personalizable en el home y otro en el footer'); //Descripción del módulo
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); //mensaje de alerta al desinstalar el módulo.
    }

    public function install() {
        if(!parent::install() || 
        !$this->registerHook('displayHome') || 
        !$this->registerHook('displayFooterBefore') ||
        !$this->registerHook('displayHeader')) // para los estilos css
            return false;
        return true;
    }


    public function uninstall() {
        if(!parent::uninstall() || 
        !$this->unregisterHook('displayHome') || 
        !$this->unregisterHook('displayFooterBefore') ||
        !$this->unregisterHook('displayHeader'))
            return false;
        return true;
    }

    public function getContent() {
        return $this->postProcess() . $this->getForm();
    }

    public function getForm() {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->languages = $this->context->controller->getLanguages();
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = $this->context->controller->default_form_language;
        $helper->allow_employee_form_lang = $this->context->controller->allow_employee_form_lang;
        $helper->title = $this->displayName;

        $helper->submit_action = 'isa_modTarea1';
        $helper->fields_value['texto'] = Configuration::get('ISA_MODULO_TEXTO_HOME');
        $helper->fields_value['textofooter'] = Configuration::get('ISA_MODULO_TEXTO_FOOTER');
        
        $this->form[0] = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->displayName
                 ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Texto'),
                        'desc' => $this->l('Qué texto quieres que aparezca en la página de inicio'),
                        'hint' => $this->l('Este texto se mostrará en la Home'),
                        'name' => 'texto',
                        'lang' => false,
                     ),
                     array(
                        'type' => 'text',
                        'label' => $this->l('TextoFooter'),
                        'desc' => $this->l('Qué texto quieres que aparezca en el footer'),
                        'hint' => $this->l('Este texto se mostrará en el Footer'),
                        'name' => 'textofooter',
                        'lang' => false,
                     ),
                 ),
                'submit' => array(
                    'title' => $this->l('Save')
                 )
             )
         );
        return $helper->generateForm($this->form);
    }

    public function postProcess() {
        if (Tools::isSubmit('isa_modTarea1')) {
            $texto = Tools::getValue('texto');
            Configuration::updateValue('ISA_MODULO_TEXTO_HOME', $texto);
            $textoFooter = Tools::getValue('textofooter');
            Configuration::updateValue('ISA_MODULO_TEXTO_FOOTER', $textoFooter);
            return $this->displayConfirmation($this->l('Updated Successfully'));
        }
    }

    public function hookDisplayHome() {
        $texto = Configuration::get('ISA_MODULO_TEXTO_HOME');
        $this->context->smarty->assign(array(
            'texto_variable' => $texto,
        ));
        return $this->context->smarty->fetch($this->local_path.'views/templates/hook/isa_modTarea1.tpl');
    }

    public function hookDisplayFooterBefore() {
        $textoFooter = Configuration::get('ISA_MODULO_TEXTO_FOOTER');
        $this->context->smarty->assign(array(
            'texto_variable_footer' => $textoFooter,
        ));
        return $this->context->smarty->fetch($this->local_path.'views/templates/hook/isa_modTarea1_1.tpl');
    }

    public function hookDisplayHeader() {
        $this->context->controller->addCSS($this->local_path.'views/css/style.css');
    }
}