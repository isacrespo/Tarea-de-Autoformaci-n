<?php

if(!defined('_PS_VERSION_'))
exit;

class isa_modTarea5_HP extends Module {
    
    protected $config_form = false;

    public function __construct() {
        $this->name = 'isa_modTarea5_HP'; //nombre del módulo el mismo que la carpeta y la clase.
        $this->tab = 'front_office_features'; // pestaña en la que se encuentra en el backoffice.
        $this->version = '1.0.0'; //versión del módulo
        $this->author ='Isa Crespo'; // autor del módulo
        $this->need_instance = 0; //si no necesita cargar la clase en la página módulos,1 si fuese necesario.
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); //las versiones con las que el módulo es compatible.
        $this->bootstrap = true; //si usa bootstrap plantilla responsive.

        parent::__construct(); //llamada al contructor padre.

        $this->displayName = $this->l('isa_modTarea5_HP'); // Nombre del módulo
        $this->description = $this->l('Agrega información personalizada a las fichas de producto.'); //Descripción del módulo
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); //mensaje de alerta al desinstalar el módulo.
    }

    public function install() {
        if(!parent::install() || !$this->alterProductTable() ||
        !$this->registerHook('actionProductSave') || 
        !$this->registerHook('displayProductButtons') ||
        !$this->registerHook('displayAdminProductsMainStepLeftColumnMiddle')) 
            return false;
        return true;      
    }


    public function uninstall() {
        if(!parent::uninstall() || 
        $this->alterProductTable('remove') ||
        !$this->unregisterHook('actionProductSave') || 
        !$this->unregisterHook('displayProductButtons') ||
        !$this->unregisterHook('displayAdminProductsMainStepLeftColumnMiddle')) 
            return false;
        return true;       
    }
    
    /**
     * Añadimos 'campoextra' a la bbdd
     */
    public function alterProductTable($method = 'add') {
		if($method == 'add') {
            $sql = 'ALTER TABLE ' . _DB_PREFIX_ . 'product ADD `campoextra` VARCHAR (255) NOT NULL';
        }
		else { 
            $sql = 'ALTER TABLE ' . _DB_PREFIX_ . 'product DROP COLUMN `campoextra`';
        }

		if(!Db::getInstance()->Execute($sql))
			return false;
		return true;
	}
  
    public function hookActionProductSave() {
        if(Tools::isSubmit('campoextra')) {
            if(!Db::getInstance()->update('product', array('campoextra' => Tools::getValue('campoextra')), 'id_product = ' . (int)Tools::getValue('id_product')))
                $this->controller->errors[] = Tools::displayError('Error while updating campoextra');
            }		
    }
    
    public function hookDisplayProductButtons() {
        $campoextra = Db::getInstance()->getValue('SELECT campoextra FROM '._DB_PREFIX_.'product WHERE id_product = ' . (int)Tools::getValue('id_product'));
        $this->context->smarty->assign('campoextra', $campoextra);
        return $this->display(__FILE__, 'isa_modTarea5_HP.tpl');
    }
    
    public function hookDisplayAdminProductsMainStepLeftColumnMiddle()  {
        return $this->display(__FILE__, 'isa_modTarea5_HP_BO.tpl');
    }
}