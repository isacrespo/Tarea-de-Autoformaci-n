<?php

if(!defined('_PS_VERSION_'))
exit;

class isa_modTarea3_Weather extends Module {

    public function __construct() {
        $this->name = 'isa_modTarea3_Weather'; //nombre del módulo el mismo que la carpeta y la clase.
        $this->tab = 'front_office_features'; // pestaña en la que se encuentra en el backoffice.
        $this->version = '1.0.0'; //versión del módulo
        $this->author ='Isa Crespo'; // autor del módulo
        $this->need_instance = 0; //si no necesita cargar la clase en la página módulos,1 si fuese necesario.
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); //las versiones con las que el módulo es compatible.
        $this->bootstrap = true; //si usa bootstrap plantilla responsive.

        parent::__construct(); //llamada al contructor padre.

        $this->displayName = $this->l('isa_modTarea3_Weather'); // Nombre del módulo
        $this->description = $this->l('Muestra las condiciones climáticas en la ciudad del visitante.'); //Descripción del módulo
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?'); //mensaje de alerta al desinstalar el módulo.
    }

    public function install() {
        if(!parent::install() || !$this->registerHook('displayNav2') || !$this->registerHook('displayHeader')) 
            return false;
        return true;      
    }


    public function uninstall() {
        if(!parent::uninstall() || !$this->unregisterHook('displayNav2') || !$this->unregisterHook('displayHeader')) 
            return false;
        return true;
    }
    
    /**
     * Llamamos a este método en el hookDisplayNav2.
     * Guardamos la ip del visitante, a partir de ella obtenemos la ciudad
     * Con el dato de la ciudad, llamamos a la Api del tiempo 
     * 
     * @return object $data
     */
    protected function weatherData() {
        // obtenemos la ip del ordenador conectado
        $ip = Tools::getRemoteAddr();

        // obtenemos la ciudad que corresponde a esa ip
        $handlecity = curl_init();
        $url = ('https://ipapi.co/'.$ip.'/city/');
        
        curl_setopt($handlecity, CURLOPT_URL, $url);
        curl_setopt($handlecity, CURLOPT_RETURNTRANSFER, true);
        
        $city = curl_exec($handlecity);
        curl_close($handlecity);
        
        // accedemos a la API del tiempo para descargar los datos climatológicos para esa ciudad
        $handle = curl_init();
        $url = ('http://api.openweathermap.org/data/2.5/weather?q='.$city.'&appid=4ab8407c3984eb2af830dee12290250f&units=metric');
        
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        
        $output = curl_exec($handle);
        curl_close($handle);
        
        $data = json_decode($output);
        return $data;
    }

    public function hookDisplayNav2() {
        $data = $this->weatherData();
            
        $this->context->smarty->assign(
            array(
                'city' => $data->name,
                'wind' => $data->wind->speed,
                'weather' => $data->weather[0]->main,
                'temp' => $data->main->temp,
                'icon' => $data->weather[0]->icon,
                'humidity' => $data->main->humidity,
            )
        );
       
       return $this->context->smarty->fetch($this->local_path.'views/templates/hook/isa_modTarea3_Weather.tpl');
    }

    public function hookDisplayHeader() {
        $this->context->controller->addCSS($this->local_path.'views/css/isa_modTarea3_Weather_style.css');
    }
}