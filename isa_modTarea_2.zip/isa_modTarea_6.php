<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

 
header('Content-Type: text/html;charset=utf-8');
define('_PS_ADMIN_DIR_', getcwd());
include(_PS_ADMIN_DIR_.'/../config/config.inc.php');

// incluimos las funciones php de Prestashop que vamos a usar
include(_PS_ADMIN_DIR_.'/functions.php');
// incluimos el script php que hace las importaciones de CSV de Prestashop
include_once '../controllers/admin/AdminImportController.php';

$import = New AdminImportController();  
loadProductsPost();
$import->productImport();

function loadProductsPost() {
  $_POST = array (
    'tab' => 'AdminImportController',
    'truncate'=>'1', //Eliminar los productos y luego importar
    'skip' => '1', //Filas a saltar en el .csv
    'csv' => 'productos.csv', //Nombre del .csv
    'convert' => '',
    'entity' => '1',
    'separator' => ',', //Separador dentro del .csv
    'multiple_value_separator' => ';',
    'import' => 'Importar datos CSV',
    'iso_lang' => 'es', //ISO lenguaje
    'forceIDs' => '1', //Forzar ID
    'regenerate' => '1', //Regenerar miniatura
    'type_value' =>
    array (
      0 => 'name',
      1 => 'reference',
      2 => 'ean13',
      3 => 'wholesale_price',
      4 => 'price_tex', 
      5 => 'ecotax', //iva
      6 => 'quantity', 
      7 => 'category', 
      8 => 'manufacturer', //fabricante
    ),
  );
}